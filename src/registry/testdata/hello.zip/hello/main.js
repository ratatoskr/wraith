import { log } from "wraith";
log.info("hello");
